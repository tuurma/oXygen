For use with Saxon CE (XSLT processor in Javascript)
