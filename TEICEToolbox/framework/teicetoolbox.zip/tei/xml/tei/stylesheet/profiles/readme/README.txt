README format for TEI releases
