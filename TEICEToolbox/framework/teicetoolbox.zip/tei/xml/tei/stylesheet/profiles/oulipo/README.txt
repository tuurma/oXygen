OuLiPo transcription project

